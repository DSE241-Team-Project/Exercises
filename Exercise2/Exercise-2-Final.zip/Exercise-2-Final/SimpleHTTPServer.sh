python -m SimpleHTTPServer 8888 & 
